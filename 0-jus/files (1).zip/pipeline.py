"""
pipeline.py
-----------
Executa o pipeline completo de treinamento em sequência:
  1. Gera / carrega dados
  2. Processa features
  3. Treina e calibra o modelo
  4. Faz uma previsão de exemplo

Execute com:  python pipeline.py
"""

import os, sys, time

os.chdir(os.path.dirname(os.path.abspath(__file__)))

def titulo(txt):
    print(f"\n{'─'*54}")
    print(f"  {txt}")
    print(f"{'─'*54}")


# ── PASSO 1: Dados ───────────────────────────────────────────────────
titulo("PASSO 1 — Gerando dados simulados")
from importlib import import_module

import pandas as pd
import numpy as np

exec(open("1_gerar_dados.py").read())

# ── PASSO 2: Features ────────────────────────────────────────────────
titulo("PASSO 2 — Feature engineering")

df_raw = pd.read_csv("data/processos_raw.csv")

# importa e executa a função processar
import importlib.util, types

spec = importlib.util.spec_from_file_location("fe", "2_feature_engineering.py")
fe   = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fe)
df_feat, features = fe.processar(df_raw)

# ── PASSO 3: Treinamento ─────────────────────────────────────────────
titulo("PASSO 3 — Treinando o modelo XGBoost")

spec2 = importlib.util.spec_from_file_location("tr", "3_treinar_modelo.py")
tr    = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(tr)
modelo, metadata = tr.treinar()

# ── PASSO 4: Previsão de exemplo ─────────────────────────────────────
titulo("PASSO 4 — Testando previsão num caso real")

spec3 = importlib.util.spec_from_file_location("pr", "4_prever.py")
pr    = importlib.util.module_from_spec(spec3)
spec3.loader.exec_module(pr)

caso_teste = {
    "tribunal":              "TJSP",
    "tema":                  "Dano moral consumidor",
    "valor_causa":           15_000,
    "taxa_vitoria_juiz":     0.68,
    "taxa_vitoria_tribunal": 0.55,
    "taxa_vitoria_tema":     0.65,
    "prec_favoraveis":       22,
    "qualidade_provas":      2,
    "segundo_grau":          0,
}

resultado = pr.prever(caso_teste)

print(f"\n  Probabilidade : {resultado['resumo']}")
print(f"  Faixa         : {resultado['faixa']} chance  [{resultado['cor']}]")
print(f"\n  Top 3 fatores que mais pesaram:")
for i, (feat, val) in enumerate(list(resultado["contribuicoes_shap"].items())[:3]):
    sinal = "aumenta" if val >= 0 else "reduz"
    print(f"    {i+1}. {feat} → {sinal} a chance ({val:+.3f})")

# ── Resumo final ─────────────────────────────────────────────────────
titulo("PIPELINE CONCLUÍDO")
print(f"  Modelo  : models/modelo_jurimetria.pkl")
print(f"  AUC-ROC : {metadata['auc_cv_medio']:.4f} ± {metadata['auc_cv_std']:.4f}")
print(f"  Brier   : {metadata['brier_score']:.4f}")
print(f"\n  Próximos passos:")
print(f"    → Substituir 1_gerar_dados.py pela coleta real do DataJud")
print(f"    → Adicionar embeddings de ementa (BERTimbau)")
print(f"    → Agendar re-treinamento mensal automático")
