"""
2_feature_engineering.py
------------------------
Transforma os dados brutos em features prontas para o modelo.
Salva o dataset processado em data/features.csv.
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
import json, os

def processar(df: pd.DataFrame) -> pd.DataFrame:

    df = df.copy()

    # ── 1. Feature: log do valor da causa ───────────────────────────
    # Valor da causa tem distribuição muito assimétrica (ex: R$1k vs R$1M)
    # Log-transformar deixa a escala razoável para o modelo
    df["log_valor"] = np.log1p(df["valor_causa"])

    # ── 2. Feature: taxa histórica de vitória por tribunal ──────────
    # Calcula a média de procedência por tribunal nos dados de treino
    taxa_trib = df.groupby("tribunal")["label"].mean().rename("taxa_vitoria_tribunal")
    df = df.merge(taxa_trib, on="tribunal", how="left")

    # ── 3. Feature: taxa histórica de vitória por tema ───────────────
    taxa_tema = df.groupby("tema")["label"].mean().rename("taxa_vitoria_tema")
    df = df.merge(taxa_tema, on="tema", how="left")

    # ── 4. Encoding de variáveis categóricas ─────────────────────────
    # LabelEncoder transforma "TJSP" → 0, "TJRJ" → 1, etc.
    le_trib = LabelEncoder()
    le_tema = LabelEncoder()
    df["tribunal_enc"] = le_trib.fit_transform(df["tribunal"])
    df["tema_enc"]     = le_tema.fit_transform(df["tema"])

    # Salva os encoders para usar na inferência (caso novo)
    os.makedirs("models", exist_ok=True)
    mapeamento = {
        "tribunal": dict(zip(le_trib.classes_.tolist(),
                             le_trib.transform(le_trib.classes_).tolist())),
        "tema":     dict(zip(le_tema.classes_.tolist(),
                             le_tema.transform(le_tema.classes_).tolist())),
    }
    with open("models/encoders.json", "w") as f:
        json.dump(mapeamento, f, ensure_ascii=False, indent=2)

    # ── 5. Feature: grau do processo (1ª ou 2ª instância) ────────────
    # Processos em 2ª instância tendem a ter resultados diferentes
    df["segundo_grau"] = (df["grau"] == 2).astype(int)

    # ── 6. Feature: normalização dos precedentes ─────────────────────
    df["prec_norm"] = np.clip(df["prec_favoraveis"] / 50.0, 0, 1)

    # ── 7. Seleciona apenas as colunas que entram no modelo ──────────
    FEATURES = [
        "tribunal_enc",          # tribunal codificado
        "tema_enc",              # tema codificado
        "log_valor",             # log do valor da causa
        "taxa_vitoria_juiz",     # histórico do juiz
        "taxa_vitoria_tribunal", # histórico do tribunal
        "taxa_vitoria_tema",     # histórico do tema
        "prec_norm",             # precedentes favoráveis (normalizado)
        "qualidade_provas",      # 0=fraca, 1=média, 2=forte
        "segundo_grau",          # 1ª ou 2ª instância
    ]

    df_out = df[FEATURES + ["label", "numero_processo"]].copy()
    df_out.to_csv("data/features.csv", index=False)

    print(f"✅  Features geradas: {df_out.shape[0]:,} linhas × {len(FEATURES)} features")
    print(f"    Features usadas: {FEATURES}")
    print(f"    Arquivo: data/features.csv")
    return df_out, FEATURES


if __name__ == "__main__":
    df_raw = pd.read_csv("data/processos_raw.csv")
    df_feat, features = processar(df_raw)
    print(f"\n    Amostra:\n{df_feat[features].head(3).to_string()}")
