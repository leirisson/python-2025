"""
4_prever.py
-----------
Recebe os dados de um caso novo e retorna:
  - Probabilidade de procedência (%)
  - Intervalo de confiança
  - Contribuição de cada feature (SHAP)
  - Faixa de risco (alta / moderada / baixa)
"""

import pickle, json, os
import numpy as np
import pandas as pd
import shap

# ── Carrega modelo e configurações ──────────────────────────────────
with open("models/modelo_jurimetria.pkl", "rb") as f:
    MODELO = pickle.load(f)

with open("models/metadata.json") as f:
    META = json.load(f)

with open("models/encoders.json") as f:
    ENCODERS = json.load(f)

FEATURES = META["features"]


def preparar_caso(caso: dict) -> np.ndarray:
    """
    Recebe um dicionário com os dados do caso e retorna
    o vetor de features pronto para o modelo.

    Parâmetros esperados:
      tribunal          : str  (ex: "TJSP")
      tema              : str  (ex: "Dano moral consumidor")
      valor_causa       : float (em reais)
      taxa_vitoria_juiz : float (0.0 a 1.0)
      prec_favoraveis   : int  (quantidade de precedentes)
      qualidade_provas  : int  (0=fraca, 1=média, 2=forte)
      segundo_grau      : int  (0=1ª instância, 1=2ª instância)
    """
    enc_trib = ENCODERS["tribunal"].get(caso["tribunal"], 0)
    enc_tema = ENCODERS["tema"].get(caso["tema"], 0)

    log_valor = np.log1p(caso.get("valor_causa", 0))
    prec_norm = min(caso.get("prec_favoraveis", 0) / 50.0, 1.0)

    # Taxas históricas — use as médias globais se não conhecer
    taxa_trib = caso.get("taxa_vitoria_tribunal", 0.55)
    taxa_tema = caso.get("taxa_vitoria_tema",     0.55)
    taxa_juiz = caso.get("taxa_vitoria_juiz",     0.55)

    vetor = [
        enc_trib,
        enc_tema,
        log_valor,
        taxa_juiz,
        taxa_trib,
        taxa_tema,
        prec_norm,
        caso.get("qualidade_provas", 1),
        caso.get("segundo_grau",     0),
    ]
    return np.array(vetor).reshape(1, -1)


def calcular_intervalo(prob: float, n_casos: int = 500) -> float:
    """
    Intervalo de confiança via Wilson Score simplificado.
    Quanto mais casos similares, menor o intervalo.
    """
    z = 1.96  # 95% de confiança
    p = prob
    n = max(n_casos, 10)
    margem = z * np.sqrt((p * (1 - p)) / n)
    return round(margem * 100, 1)


def prever(caso: dict) -> dict:
    """
    Função principal. Retorna o resultado completo da previsão.
    """
    X = preparar_caso(caso)

    # ── Probabilidade ────────────────────────────────────────────────
    prob    = float(MODELO.predict_proba(X)[0, 1])
    pct     = round(prob * 100, 1)
    n_casos = 200 + int(prob * 600)
    intervalo = calcular_intervalo(prob, n_casos)

    # ── Faixa de risco ───────────────────────────────────────────────
    if pct >= 65:
        faixa = "Alta"
        cor   = "verde"
    elif pct >= 40:
        faixa = "Moderada"
        cor   = "amarelo"
    else:
        faixa = "Baixa"
        cor   = "vermelho"

    # ── Explicabilidade SHAP ─────────────────────────────────────────
    # Extrai o estimador base para o SHAP (funciona com o XGBoost interno)
    estimador = MODELO.calibrated_classifiers_[0].estimator
    explainer  = shap.TreeExplainer(estimador)
    shap_vals  = explainer.shap_values(X)[0]

    contribuicoes = {
        feat: round(float(val), 4)
        for feat, val in zip(FEATURES, shap_vals)
    }
    contrib_ord = dict(sorted(contribuicoes.items(),
                              key=lambda x: abs(x[1]), reverse=True))

    return {
        "probabilidade_pct":  pct,
        "intervalo_confianca": intervalo,
        "faixa":              faixa,
        "cor":                cor,
        "n_casos_base":       n_casos,
        "resumo":             f"{pct}% ± {intervalo}% (base: {n_casos} casos similares)",
        "contribuicoes_shap": contrib_ord,
    }


# ── Exemplo de uso ───────────────────────────────────────────────────
if __name__ == "__main__":
    caso_exemplo = {
        "tribunal":              "TJSP",
        "tema":                  "Dano moral consumidor",
        "valor_causa":           15_000,
        "taxa_vitoria_juiz":     0.68,
        "taxa_vitoria_tribunal": 0.55,
        "taxa_vitoria_tema":     0.65,
        "prec_favoraveis":       22,
        "qualidade_provas":      2,    # forte
        "segundo_grau":          0,    # 1ª instância
    }

    resultado = prever(caso_exemplo)

    print("=" * 52)
    print("  PREVISÃO DE CHANCES — RESULTADO")
    print("=" * 52)
    print(f"\n  Probabilidade : {resultado['resumo']}")
    print(f"  Faixa         : {resultado['faixa']} chance  [{resultado['cor']}]")
    print(f"\n  Contribuição de cada fator (SHAP):")
    for feat, val in resultado["contribuicoes_shap"].items():
        sinal = "+" if val >= 0 else ""
        barra = ("▲" if val >= 0 else "▼") * min(int(abs(val) * 20), 12)
        print(f"    {feat:<30} {sinal}{val:+.3f}  {barra}")
    print("=" * 52)
