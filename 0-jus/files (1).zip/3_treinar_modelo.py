"""
3_treinar_modelo.py
-------------------
Treina o modelo XGBoost com validação cruzada estratificada,
calibra as probabilidades e salva o modelo final.
"""

import pandas as pd
import numpy as np
import json, os, pickle

from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.metrics import (
    roc_auc_score, brier_score_loss,
    classification_report, confusion_matrix,
)
from xgboost import XGBClassifier

SEED = 42

FEATURES = [
    "tribunal_enc", "tema_enc", "log_valor",
    "taxa_vitoria_juiz", "taxa_vitoria_tribunal", "taxa_vitoria_tema",
    "prec_norm", "qualidade_provas", "segundo_grau",
]


def treinar():
    # ── Carrega dados ────────────────────────────────────────────────
    df = pd.read_csv("data/features.csv")
    X  = df[FEATURES].values
    y  = df["label"].values

    print(f"Dataset: {len(df):,} processos | "
          f"procedentes: {y.mean()*100:.1f}%\n")

    # ── Modelo base XGBoost ──────────────────────────────────────────
    # Hiperparâmetros escolhidos para dados jurídicos tabulares:
    # - n_estimators: número de árvores (100 é bom ponto de partida)
    # - max_depth: profundidade máxima (3-5 evita overfitting)
    # - learning_rate: passo de aprendizado (0.1 é padrão seguro)
    # - scale_pos_weight: corrige desbalanceamento de classes
    neg, pos = (y == 0).sum(), (y == 1).sum()
    spw = neg / pos  # ex: se 60% proc e 40% improc → spw = 0.67

    modelo_base = XGBClassifier(
        n_estimators     = 200,
        max_depth        = 4,
        learning_rate    = 0.05,
        subsample        = 0.8,       # usa 80% das linhas por árvore
        colsample_bytree = 0.8,       # usa 80% das features por árvore
        scale_pos_weight = spw,
        random_state     = SEED,
        eval_metric      = "auc",
        verbosity        = 0,
        use_label_encoder= False,
    )

    # ── Validação cruzada (5 folds) ──────────────────────────────────
    # Garante que o modelo generaliza para processos que não viu
    print("🔄  Validação cruzada (5 folds)...")
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

    aucs    = cross_val_score(modelo_base, X, y, cv=cv, scoring="roc_auc")
    briers  = cross_val_score(modelo_base, X, y, cv=cv, scoring="neg_brier_score")

    print(f"    AUC-ROC médio : {aucs.mean():.4f} ± {aucs.std():.4f}")
    print(f"    Brier score   : {(-briers.mean()):.4f} ± {briers.std():.4f}")
    print()

    # ── Calibração de probabilidades ─────────────────────────────────
    # O XGBoost produz scores, não probabilidades reais.
    # CalibratedClassifierCV com method='isotonic' ajusta isso.
    print("⚙️   Calibrando probabilidades (Isotonic Regression)...")
    modelo_calibrado = CalibratedClassifierCV(
        modelo_base,
        method = "isotonic",   # melhor para datasets grandes
        cv     = 5,
    )
    modelo_calibrado.fit(X, y)

    # ── Avaliação final no conjunto completo ─────────────────────────
    probs = modelo_calibrado.predict_proba(X)[:, 1]
    preds = (probs >= 0.5).astype(int)

    auc_final    = roc_auc_score(y, probs)
    brier_final  = brier_score_loss(y, probs)

    print(f"\n📊  Métricas finais (conjunto completo):")
    print(f"    AUC-ROC     : {auc_final:.4f}")
    print(f"    Brier score : {brier_final:.4f}  (0 = perfeito, 0.25 = chute)")
    print()
    print("    Relatório de classificação:")
    print(classification_report(y, preds,
          target_names=["Improcedente", "Procedente"]))

    # ── Importância das features ──────────────────────────────────────
    # Extrai importância do estimador base dentro do calibrador
    estimador_base = modelo_calibrado.calibrated_classifiers_[0].estimator
    importancias = dict(zip(FEATURES, estimador_base.feature_importances_))
    importancias_ord = dict(sorted(importancias.items(),
                                   key=lambda x: x[1], reverse=True))

    print("    Importância das features:")
    for feat, imp in importancias_ord.items():
        barra = "█" * int(imp * 40)
        print(f"      {feat:<30} {barra} {imp:.4f}")

    # ── Salva modelo e metadados ──────────────────────────────────────
    os.makedirs("models", exist_ok=True)

    with open("models/modelo_jurimetria.pkl", "wb") as f:
        pickle.dump(modelo_calibrado, f)

    metadata = {
        "features":       FEATURES,
        "n_treino":       int(len(df)),
        "auc_cv_medio":   round(float(aucs.mean()), 4),
        "auc_cv_std":     round(float(aucs.std()),  4),
        "brier_score":    round(float(brier_final), 4),
        "importancias":   {k: round(float(v), 4) for k, v in importancias_ord.items()},
        "threshold":      0.5,
        "versao":         "1.0.0",
    }
    with open("models/metadata.json", "w") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)

    print(f"\n✅  Modelo salvo em models/modelo_jurimetria.pkl")
    print(f"    Metadados   em models/metadata.json")
    return modelo_calibrado, metadata


if __name__ == "__main__":
    treinar()
